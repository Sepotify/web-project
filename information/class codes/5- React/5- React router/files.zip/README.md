# React Router with Vite - Hello World Example

## Installation

First, create a new Vite project and install React Router:

```bash
# Create a new Vite project
npm create vite@latest my-app -- --template react
cd my-app

# Install React Router
npm install react-router-dom

# Install dependencies
npm install

# Run the development server
npm run dev
```

## Project Structure

```
src/
├── App.jsx          # Main app with router configuration
├── components/
│   ├── Home.jsx     # Home page component
│   ├── About.jsx    # About page component
│   ├── User.jsx     # User detail page with URL params
│   └── NotFound.jsx # 404 page
└── main.jsx         # Entry point
```

## Features Demonstrated

- Basic routing setup
- Navigation with Link components
- Dynamic route parameters
- Nested routes
- 404 Not Found page
- Programmatic navigation
